.. house_price_prediction documentation master file, created by
   sphinx-quickstart on Wed May  4 17:39:58 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to house_price_prediction's documentation!
==================================================

.. toctree::
   :maxdepth: 5
   :caption: Contents:

   modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
