house\_price\_prediction\_satish package
========================================

Submodules
----------

house\_price\_prediction\_satish.ingest\_data module
----------------------------------------------------

.. automodule:: house_price_prediction_satish.ingest_data
   :members:
   :undoc-members:
   :show-inheritance:

house\_price\_prediction\_satish.nonstandardcode module
-------------------------------------------------------

.. automodule:: house_price_prediction_satish.nonstandardcode
   :members:
   :undoc-members:
   :show-inheritance:

house\_price\_prediction\_satish.score module
---------------------------------------------

.. automodule:: house_price_prediction_satish.score
   :members:
   :undoc-members:
   :show-inheritance:

house\_price\_prediction\_satish.train module
---------------------------------------------

.. automodule:: house_price_prediction_satish.train
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: house_price_prediction_satish
   :members:
   :undoc-members:
   :show-inheritance:
