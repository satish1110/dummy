# tc1: Test installation of env
import logging
import os
import tarfile

import numpy as np
import pandas as pd
import sklearn
from scipy.stats import randint
from six.moves import urllib

data_path = "datasets//housing"

# read the datasets from the path
housing = pd.read_csv(data_path + "//housing.csv")
housing_labels = pd.read_csv(data_path + "//housing_labels.csv")
housing_prepared = pd.read_csv(data_path + "//housing_prepared.csv")
strat_train_set = pd.read_csv(data_path + "//strat_train_set.csv")
strat_test_set = pd.read_csv(data_path + "//strat_test_set.csv")
test_set = pd.read_csv(data_path + "//test_set.csv")
X_test_prepared = pd.read_csv(data_path + "//X_test_prepared.csv")
y_test = pd.read_csv(data_path + "//y_test.csv")


def test_install():
    """
    Test the installation in the env
    """
    print("TC1: Installation successful!")


def test_rows():
    """
    Test the correctness of the rows of data
    """
    assert housing.shape[0] == 20640
    assert housing_labels.shape[0] == 16512
    assert housing_prepared.shape[0] == 16512
    assert strat_train_set.shape[0] == 16512
    assert strat_test_set.shape[0] == 4128
    assert test_set.shape[0] == 4128
    assert X_test_prepared.shape[0] == 4128
    assert y_test.shape[0] == 4128
    print("TC2: Rows verified successfully!")


def test_columns():
    """
    Test the correctness of the columns of data
    """
    assert housing.shape[1] == 10
    assert housing_labels.shape[1] == 1
    assert housing_prepared.shape[1] == 15
    assert strat_train_set.shape[1] == 10
    assert strat_test_set.shape[1] == 10
    assert test_set.shape[1] == 11
    assert X_test_prepared.shape[1] == 15
    assert y_test.shape[1] == 1

    print("TC2: Columns verified successfully!")


if __name__ == "__main__":
    """
    Driver function to call other functions in order
    """
    test_install()
    test_rows()
    test_columns()
